// Example 1
if (x === 3) {
  console.log("x is 3");
}

// Example 2
if (x === 3) {
  console.log("x is 3");
} else {
  console.log("x is NOT 3");
}

// Example 3
if (x === 3) console.log("x is 3");

// Example 4
if (x === 3)
  console.log("x is 3");

// Example 5
if (x === 3)
  console.log("x is 3");
else
  console.log("x is NOT 3");

// Example 6
if (x === 3) {
  console.log('x is 3');
} else {
  if (x === 4) {
    console.log('x is 4');
  } else {
    console.log('x is NOT 3 or 4');
  }
}

// Example 7
if (x === 3) {
  console.log("x is 3");
} else if (x === 4) {
  console.log("x is 4");
} else {
  console.log('x is NOT 3 or 4');
}
